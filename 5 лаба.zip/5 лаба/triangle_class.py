from triangle_func import IncorrectTriangleSides  # повторное использование исключения


class Triangle:
    """
    Класс, представляющий треугольник по трём сторонам.
    """

    def __init__(self, a, b, c):
        """
        Конструктор треугольника.

        Аргументы:
            a, b, c (float или int): длины сторон.

        Исключения:
            IncorrectTriangleSides: если стороны не образуют треугольник
                                    или не положительны.
        """
        # Валидация (та же логика, что в get_triangle_type)
        if a <= 0 or b <= 0 or c <= 0:
            raise IncorrectTriangleSides("Стороны должны быть положительными числами")

        if a + b <= c or a + c <= b or b + c <= a:
            raise IncorrectTriangleSides("Стороны не образуют треугольник")

        self.a = a
        self.b = b
        self.c = c

    def triangle_type(self):
        """
        Возвращает тип треугольника.

        Returns:
            str: "equilateral", "isosceles", "nonequilateral"
        """
        if self.a == self.b == self.c:
            return "equilateral"
        elif self.a == self.b or self.b == self.c or self.a == self.c:
            return "isosceles"
        else:
            return "nonequilateral"

    def perimeter(self):
        """
        Возвращает периметр треугольника.

        Returns:
            float или int: сумма длин сторон.
        """
        return self.a + self.b + self.c