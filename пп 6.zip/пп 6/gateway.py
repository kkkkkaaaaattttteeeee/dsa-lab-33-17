from flask import Flask, render_template, request, jsonify
import requests
import json

app = Flask(__name__)

CURRENCY_MANAGER = "http://localhost:5001"
DATA_MANAGER = "http://localhost:5002"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/load', methods=['POST'])
def proxy_load():
    try:
        data = request.get_json()
        print(f"Proxying load request: {data}")
        
        response = requests.post(
            f"{CURRENCY_MANAGER}/load",
            json=data,
            timeout=10
        )
        print(f"Response status: {response.status_code}")
        print(f"Response body: {response.text}")
        
        return jsonify(response.json()), response.status_code
    except requests.exceptions.ConnectionError as e:
        print(f"Connection error: {e}")
        return jsonify({"error": "Currency Manager service is unavailable"}), 503
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/update', methods=['POST'])
def proxy_update():
    try:
        data = request.get_json()
        print(f"Proxying update request: {data}")
        
        response = requests.post(
            f"{CURRENCY_MANAGER}/update_currency",
            json=data,
            timeout=10
        )
        print(f"Response status: {response.status_code}")
        print(f"Response body: {response.text}")
        
        return jsonify(response.json()), response.status_code
    except requests.exceptions.ConnectionError as e:
        print(f"Connection error: {e}")
        return jsonify({"error": "Currency Manager service is unavailable"}), 503
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/delete', methods=['POST'])
def proxy_delete():
    try:
        data = request.get_json()
        print(f"Proxying delete request: {data}")
        
        response = requests.post(
            f"{CURRENCY_MANAGER}/delete",
            json=data,
            timeout=10
        )
        print(f"Response status: {response.status_code}")
        print(f"Response body: {response.text}")
        
        return jsonify(response.json()), response.status_code
    except requests.exceptions.ConnectionError as e:
        print(f"Connection error: {e}")
        return jsonify({"error": "Currency Manager service is unavailable"}), 503
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/convert', methods=['GET'])
def proxy_convert():
    try:
        currency = request.args.get('currency')
        amount = request.args.get('amount')
        print(f"Proxying convert request: currency={currency}, amount={amount}")
        
        response = requests.get(
            f"{DATA_MANAGER}/convert",
            params={"currency": currency, "amount": amount},
            timeout=10
        )
        print(f"Response status: {response.status_code}")
        print(f"Response body: {response.text}")
        
        return jsonify(response.json()), response.status_code
    except requests.exceptions.ConnectionError as e:
        print(f"Connection error: {e}")
        return jsonify({"error": "Data Manager service is unavailable"}), 503
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/currencies', methods=['GET'])
def proxy_currencies():
    try:
        print("Proxying currencies request")
        
        response = requests.get(
            f"{DATA_MANAGER}/currencies",
            timeout=10
        )
        print(f"Response status: {response.status_code}")
        print(f"Response body: {response.text}")
        
        return jsonify(response.json()), response.status_code
    except requests.exceptions.ConnectionError as e:
        print(f"Connection error: {e}")
        return jsonify({"error": "Data Manager service is unavailable"}), 503
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404

if __name__ == '__main__':
    print("=" * 50)
    print("Gateway starting on http://localhost:5000")
    print("=" * 50)
    app.run(host='127.0.0.1', port=5000, debug=True)