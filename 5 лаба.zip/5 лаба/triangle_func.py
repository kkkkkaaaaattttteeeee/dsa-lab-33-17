class IncorrectTriangleSides(Exception):
    """Исключение при некорректных сторонах треугольника."""
    pass


def get_triangle_type(a, b, c):
    """
    Возвращает тип треугольника.
    
    Returns:
        "equilateral" - равносторонний
        "isosceles" - равнобедренный  
        "nonequilateral" - разносторонний
    
    Raises:
        IncorrectTriangleSides: если стороны некорректны
    """
    # Проверка положительности сторон
    if a <= 0 or b <= 0 or c <= 0:
        raise IncorrectTriangleSides("Стороны должны быть положительными")
    
    # Проверка неравенства треугольника
    if a + b <= c or a + c <= b or b + c <= a:
        raise IncorrectTriangleSides("Стороны не образуют треугольник")
    
    # Определение типа
    if a == b == c:
        return "equilateral"
    elif a == b or b == c or a == c:
        return "isosceles"
    else:
        return "nonequilateral"