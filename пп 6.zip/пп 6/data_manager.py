from flask import Flask, request, jsonify
import psycopg2
from psycopg2 import pool

app = Flask(__name__)

# Настройки БД
DB_CONFIG = {
    'dbname': 'currency_db',
    'user': 'postgres',
    'password': '1029384756',
    'host': 'localhost',
    'port': '5432'
}

# Пул соединений
connection_pool = psycopg2.pool.SimpleConnectionPool(1, 10, **DB_CONFIG)

def get_db_connection():
    return connection_pool.getconn()

def release_db_connection(conn):
    connection_pool.putconn(conn)

@app.route('/convert', methods=['GET'])
def convert_currency():
    try:
        currency_name = request.args.get('currency', '').strip().upper()
        amount = float(request.args.get('amount', 0))
        
        if not currency_name or amount <= 0:
            return jsonify({"error": "Invalid parameters"}), 400
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Проверка существования валюты
        cur.execute(
            "SELECT rate FROM currencies WHERE currency_name = %s",
            (currency_name,)
        )
        result = cur.fetchone()
        
        if not result:
            cur.close()
            release_db_connection(conn)
            return jsonify({"error": f"Currency {currency_name} not found"}), 404
        
        rate = float(result[0])
        converted_amount = round(amount * rate, 2)
        
        cur.close()
        release_db_connection(conn)
        
        return jsonify({
            "currency": currency_name,
            "original_amount": amount,
            "rate": rate,
            "converted_amount": converted_amount,
            "result": f"{amount} {currency_name} = {converted_amount} RUB"
        }), 200
        
    except ValueError:
        return jsonify({"error": "Amount must be a number"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/currencies', methods=['GET'])
def get_currencies():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        
        cur.execute("SELECT id, currency_name, rate FROM currencies ORDER BY currency_name")
        currencies = cur.fetchall()
        
        result = []
        for currency in currencies:
            result.append({
                "id": currency[0],
                "currency_name": currency[1],
                "rate": float(currency[2])
            })
        
        cur.close()
        release_db_connection(conn)
        return jsonify({
            "count": len(result),
            "currencies": result
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "Data Manager is running"}), 200

if __name__ == '__main__':
    print("Data Manager starting on port 5002...")
    app.run(host='0.0.0.0', port=5002, debug=False)