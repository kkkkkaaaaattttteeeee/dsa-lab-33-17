from flask import Flask, request, jsonify
import psycopg2
from psycopg2 import pool
import os

app = Flask(__name__)

# Настройки БД
DB_CONFIG = {
    'dbname': 'currency_db',
    'user': 'postgres',
    'password': '1029384756',
    'host': 'localhost',
    'port': '5432'
}

# Пул соединений для лучшей производительности
connection_pool = psycopg2.pool.SimpleConnectionPool(1, 10, **DB_CONFIG)

def get_db_connection():
    return connection_pool.getconn()

def release_db_connection(conn):
    connection_pool.putconn(conn)

@app.route('/load', methods=['POST'])
def load_currency():
    try:
        data = request.get_json()
        name = data['currency_name'].strip().upper()
        rate = data['rate']
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Проверка существования валюты
        cur.execute("SELECT id FROM currencies WHERE currency_name = %s", (name,))
        if cur.fetchone():
            cur.close()
            release_db_connection(conn)
            return jsonify({"error": f"Currency {name} already exists"}), 400
        
        # Сохранение валюты
        cur.execute(
            "INSERT INTO currencies (currency_name, rate) VALUES (%s, %s)",
            (name, rate)
        )
        conn.commit()
        
        cur.close()
        release_db_connection(conn)
        return jsonify({
            "message": f"Currency {name} added successfully",
            "currency": {"name": name, "rate": rate}
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/update_currency', methods=['POST'])
def update_currency():
    try:
        data = request.get_json()
        name = data['currency_name'].strip().upper()
        rate = data['rate']
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Проверка существования валюты
        cur.execute("SELECT id FROM currencies WHERE currency_name = %s", (name,))
        if not cur.fetchone():
            cur.close()
            release_db_connection(conn)
            return jsonify({"error": f"Currency {name} not found"}), 404
        
        # Обновление курса
        cur.execute(
            "UPDATE currencies SET rate = %s WHERE currency_name = %s",
            (rate, name)
        )
        conn.commit()
        
        cur.close()
        release_db_connection(conn)
        return jsonify({
            "message": f"Currency {name} updated",
            "currency": {"name": name, "new_rate": rate}
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/delete', methods=['POST'])
def delete_currency():
    try:
        data = request.get_json()
        name = data['currency_name'].strip().upper()
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        # Проверка существования валюты
        cur.execute("SELECT id FROM currencies WHERE currency_name = %s", (name,))
        if not cur.fetchone():
            cur.close()
            release_db_connection(conn)
            return jsonify({"error": f"Currency {name} not found"}), 404
        
        # Удаление валюты
        cur.execute("DELETE FROM currencies WHERE currency_name = %s", (name,))
        conn.commit()
        
        cur.close()
        release_db_connection(conn)
        return jsonify({"message": f"Currency {name} deleted"}), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "Currency Manager is running"}), 200

if __name__ == '__main__':
    print("Currency Manager starting on port 5001...")
    app.run(host='0.0.0.0', port=5001, debug=False)