import unittest
from triangle_func import get_triangle_type, IncorrectTriangleSides


class TestTriangleFunc(unittest.TestCase):
    
    # === ПОЗИТИВНЫЕ ТЕСТЫ ===
    def test_equilateral(self):
        self.assertEqual(get_triangle_type(3, 3, 3), "equilateral")
    
    def test_isosceles(self):
        self.assertEqual(get_triangle_type(5, 5, 8), "isosceles")
    
    def test_nonequilateral(self):
        self.assertEqual(get_triangle_type(3, 4, 5), "nonequilateral")
    
    def test_isosceles_float(self):
        self.assertEqual(get_triangle_type(2.5, 2.5, 4.0), "isosceles")
    
    def test_nonequilateral_float(self):
        self.assertEqual(get_triangle_type(0.5, 0.6, 0.7), "nonequilateral")
    
    # === НЕГАТИВНЫЕ ТЕСТЫ ===
    def test_zero_side(self):
        with self.assertRaises(IncorrectTriangleSides):
            get_triangle_type(0, 5, 5)
    
    def test_negative_side(self):
        with self.assertRaises(IncorrectTriangleSides):
            get_triangle_type(-1, 2, 3)
    
    def test_inequality_violation(self):
        with self.assertRaises(IncorrectTriangleSides):
            get_triangle_type(1, 1, 3)
    
    def test_inequality_violation2(self):
        with self.assertRaises(IncorrectTriangleSides):
            get_triangle_type(10, 1, 1)
    
    def test_degenerate(self):
        with self.assertRaises(IncorrectTriangleSides):
            get_triangle_type(1.5, 2.5, 4.0)
    
    def test_invalid_type(self):
        with self.assertRaises(TypeError):
            get_triangle_type("a", 2, 3)


if __name__ == "__main__":
    unittest.main()