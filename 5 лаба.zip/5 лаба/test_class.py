# test_class.py

import pytest
from triangle_class import Triangle
from triangle_func import IncorrectTriangleSides


# === ПОЗИТИВНЫЕ ТЕСТЫ ===

def test_equilateral():
    """Тест равностороннего треугольника"""
    t = Triangle(3, 3, 3)
    assert t.triangle_type() == "equilateral"
    assert t.perimeter() == 9


def test_isosceles():
    """Тест равнобедренного треугольника"""
    t = Triangle(5, 5, 8)
    assert t.triangle_type() == "isosceles"
    assert t.perimeter() == 18


def test_nonequilateral():
    """Тест разностороннего треугольника"""
    t = Triangle(3, 4, 5)
    assert t.triangle_type() == "nonequilateral"
    assert t.perimeter() == 12


def test_float_sides():
    """Тест с вещественными числами"""
    t = Triangle(0.5, 0.6, 0.7)
    assert t.triangle_type() == "nonequilateral"
    assert t.perimeter() == pytest.approx(1.8)


def test_attributes():
    """Тест сохранения сторон"""
    t = Triangle(2, 3, 4)
    assert t.a == 2
    assert t.b == 3
    assert t.c == 4


# === НЕГАТИВНЫЕ ТЕСТЫ ===

def test_zero_side():
    """Тест с нулевой стороной"""
    with pytest.raises(IncorrectTriangleSides):
        Triangle(0, 5, 5)


def test_negative_side():
    """Тест с отрицательной стороной"""
    with pytest.raises(IncorrectTriangleSides):
        Triangle(-1, 2, 3)


def test_inequality_violation():
    """Тест нарушения неравенства треугольника"""
    with pytest.raises(IncorrectTriangleSides):
        Triangle(1, 1, 3)


def test_inequality_violation2():
    with pytest.raises(IncorrectTriangleSides):
        Triangle(10, 1, 1)


def test_degenerate():
    """Тест вырожденного треугольника"""
    with pytest.raises(IncorrectTriangleSides):
        Triangle(1.5, 2.5, 4.0)


def test_invalid_type():
    """Тест с некорректным типом данных"""
    with pytest.raises(TypeError):
        Triangle("a", 2, 3)